using System;

namespace Vraj_P_Patel_3154641_Assignment_1
{
    public class BlogType
    {
        public int BlogTypeId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
