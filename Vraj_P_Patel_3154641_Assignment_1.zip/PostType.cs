using System;

namespace Vraj_P_Patel_3154641_Assignment_1
{
    public class PostType
    {
        public int PostTypeId { get; set; }
        public string Status { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
